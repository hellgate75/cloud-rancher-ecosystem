CREATE DATABASE IF NOT EXISTS cattle COLLATE = 'utf8_general_ci' CHARACTER SET = 'utf8';
CREATE USER 'cattle'@'localhost' IDENTIFIED BY 'cattle';
CREATE USER 'cattle'@'%' IDENTIFIED BY 'cattle';
GRANT ALL ON cattle.* TO 'cattle'@'%';
GRANT ALL ON cattle.* TO 'cattle'@'localhost';
GRANT ALL ON cattle.* TO 'root'@'%';
GRANT ALL ON cattle.* TO 'root'@'localhost';
